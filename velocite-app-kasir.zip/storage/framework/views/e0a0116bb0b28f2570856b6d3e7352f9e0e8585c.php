
<?php $__env->startSection('judul_halaman', 'Halaman Home'); ?>
<?php $__env->startSection('konten'); ?>

    <p>Ini Adalah Halaman Home</p>
    <p>Selamat datang !</p>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\velocite-app-kasir\resources\views/home.blade.php ENDPATH**/ ?>